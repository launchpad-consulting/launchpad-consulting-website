import React, { useState } from 'react';
import { ArrowRight, FileText, TrendingUp, Target, CheckCircle, Mail, Phone, MapPin, ChevronRight, Download, Hexagon, Triangle, Circle, Box, Star } from 'lucide-react';

function App() {
  const [formData, setFormData] = useState({ name: '', email: '', business: '', message: '' });
  const [formSubmitted, setFormSubmitted] = useState(false);
  const backendUrl = process.env.REACT_APP_BACKEND_URL;

  const handleSubmit = (e) => {
    e.preventDefault();
    setFormSubmitted(true);
  };

  const handleDownloadSample = (type) => {
    const link = document.createElement('a');
    if (type === 'pdf') {
      link.href = `${backendUrl}/api/download-report`;
      link.download = 'Sample_Market_Research_Report.pdf';
    } else {
      link.href = `${backendUrl}/api/download-business-plan`;
      link.download = 'Sample_Business_Plan.docx';
    }
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const scrollToSection = (id) => {
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-[#FAFAFA] font-sans">
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-50 backdrop-blur-xl bg-white/80 border-b border-zinc-200">
        <div className="max-w-7xl mx-auto px-6 md:px-12 lg:px-24">
          <div className="flex items-center justify-between h-16">
            <div className="font-heading font-black text-xl tracking-tight text-zinc-950">
              LAUNCHPAD
            </div>
            <nav className="hidden md:flex items-center gap-8">
              <button onClick={() => scrollToSection('services')} className="text-sm font-medium text-zinc-600 hover:text-zinc-950 transition-colors">Services</button>
              <button onClick={() => scrollToSection('portfolio')} className="text-sm font-medium text-zinc-600 hover:text-zinc-950 transition-colors">Portfolio</button>
              <button onClick={() => scrollToSection('pricing')} className="text-sm font-medium text-zinc-600 hover:text-zinc-950 transition-colors">Pricing</button>
              <button onClick={() => scrollToSection('about')} className="text-sm font-medium text-zinc-600 hover:text-zinc-950 transition-colors">About</button>
            </nav>
            <button 
              data-testid="header-cta-btn"
              onClick={() => scrollToSection('contact')} 
              className="bg-zinc-950 text-white px-6 py-2.5 text-sm font-semibold hover:bg-zinc-800 transition-colors rounded-none"
            >
              Get Started
            </button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="pt-32 pb-24 md:pb-32 px-6 md:px-12 lg:px-24">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center">
            <div>
              <p className="text-sm uppercase tracking-[0.2em] font-bold text-blue-600 mb-6">Business Growth Consulting</p>
              <h1 className="font-heading text-5xl md:text-6xl lg:text-7xl tracking-tighter leading-[1.05] font-black text-zinc-950 mb-6">
                Turn Your Business Idea Into Reality
              </h1>
              <p className="text-lg md:text-xl leading-relaxed text-zinc-600 mb-8 max-w-xl">
                Professional business plans, market research, and growth strategies that help small business owners start strong and scale fast.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <button 
                  data-testid="hero-cta-btn"
                  onClick={() => scrollToSection('contact')} 
                  className="bg-zinc-950 text-white px-8 py-4 text-base font-semibold hover:bg-zinc-800 transition-all rounded-none inline-flex items-center gap-2 group"
                >
                  Book Free Consultation
                  <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                </button>
                <button 
                  data-testid="hero-portfolio-btn"
                  onClick={() => scrollToSection('portfolio')} 
                  className="border-2 border-zinc-950 text-zinc-950 px-8 py-4 text-base font-semibold hover:bg-zinc-950 hover:text-white transition-all rounded-none"
                >
                  View Sample Work
                </button>
              </div>
            </div>
            <div className="relative">
              <img 
                src="https://images.unsplash.com/photo-1552664730-d307ca884978?w=800&q=80" 
                alt="Business consultation" 
                className="w-full h-[400px] lg:h-[500px] object-cover"
              />
              <div className="absolute -bottom-6 -left-6 bg-white border border-zinc-200 p-6">
                <p className="text-4xl font-heading font-black text-zinc-950">150+</p>
                <p className="text-sm text-zinc-600 font-medium">Businesses Helped</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Trusted By Marquee */}
      <section className="py-12 border-y border-zinc-200 bg-white overflow-hidden">
        <div className="flex animate-marquee">
          {[...Array(2)].map((_, idx) => (
            <div key={idx} className="flex items-center gap-16 px-8">
              <div className="flex items-center gap-3 text-zinc-400">
                <Hexagon className="w-8 h-8" strokeWidth={1.5} />
                <span className="font-heading font-bold text-lg">NEXUS</span>
              </div>
              <div className="flex items-center gap-3 text-zinc-400">
                <Triangle className="w-8 h-8" strokeWidth={1.5} />
                <span className="font-heading font-bold text-lg">VERTEX</span>
              </div>
              <div className="flex items-center gap-3 text-zinc-400">
                <Circle className="w-8 h-8" strokeWidth={1.5} />
                <span className="font-heading font-bold text-lg">ORBIT</span>
              </div>
              <div className="flex items-center gap-3 text-zinc-400">
                <Box className="w-8 h-8" strokeWidth={1.5} />
                <span className="font-heading font-bold text-lg">CUBIC</span>
              </div>
              <div className="flex items-center gap-3 text-zinc-400">
                <Hexagon className="w-8 h-8" strokeWidth={1.5} />
                <span className="font-heading font-bold text-lg">PRISM</span>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-24 md:py-32 px-6 md:px-12 lg:px-24">
        <div className="max-w-7xl mx-auto">
          <p className="text-sm uppercase tracking-[0.2em] font-bold text-blue-600 mb-4">What I Do</p>
          <h2 className="font-heading text-3xl md:text-4xl lg:text-5xl tracking-tight leading-tight font-bold text-zinc-950 mb-16 max-w-2xl">
            Everything You Need to Start & Grow Your Business
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-8">
            {/* Service 1 */}
            <div className="bg-white border border-zinc-200 p-8 hover:border-zinc-950 hover:-translate-y-1 transition-all duration-300 group">
              <div className="w-14 h-14 bg-blue-50 flex items-center justify-center mb-6">
                <FileText className="w-7 h-7 text-blue-600" strokeWidth={1.5} />
              </div>
              <h3 className="font-heading text-xl md:text-2xl tracking-tight font-bold text-zinc-950 mb-3">Business Plans</h3>
              <p className="text-base text-zinc-600 leading-relaxed mb-6">
                Comprehensive business plans with financial projections, market analysis, and actionable strategies. Perfect for startups and bank applications.
              </p>
              <ul className="space-y-2">
                {['Executive Summary', 'Financial Projections', 'Marketing Strategy', 'Operations Plan'].map((item, i) => (
                  <li key={i} className="flex items-center gap-2 text-sm text-zinc-600">
                    <CheckCircle className="w-4 h-4 text-green-500" />
                    {item}
                  </li>
                ))}
              </ul>
            </div>

            {/* Service 2 */}
            <div className="bg-white border border-zinc-200 p-8 hover:border-zinc-950 hover:-translate-y-1 transition-all duration-300 group">
              <div className="w-14 h-14 bg-blue-50 flex items-center justify-center mb-6">
                <TrendingUp className="w-7 h-7 text-blue-600" strokeWidth={1.5} />
              </div>
              <h3 className="font-heading text-xl md:text-2xl tracking-tight font-bold text-zinc-950 mb-3">Market Research</h3>
              <p className="text-base text-zinc-600 leading-relaxed mb-6">
                Data-driven insights into your market, competitors, and ideal locations. Know exactly where to open and who to target.
              </p>
              <ul className="space-y-2">
                {['Location Analysis', 'Competitor Research', 'Demographics Data', 'Growth Trends'].map((item, i) => (
                  <li key={i} className="flex items-center gap-2 text-sm text-zinc-600">
                    <CheckCircle className="w-4 h-4 text-green-500" />
                    {item}
                  </li>
                ))}
              </ul>
            </div>

            {/* Service 3 */}
            <div className="bg-white border border-zinc-200 p-8 hover:border-zinc-950 hover:-translate-y-1 transition-all duration-300 group">
              <div className="w-14 h-14 bg-blue-50 flex items-center justify-center mb-6">
                <Target className="w-7 h-7 text-blue-600" strokeWidth={1.5} />
              </div>
              <h3 className="font-heading text-xl md:text-2xl tracking-tight font-bold text-zinc-950 mb-3">Growth Strategy</h3>
              <p className="text-base text-zinc-600 leading-relaxed mb-6">
                Clear roadmaps for scaling your business. From marketing plans to expansion strategies, I'll show you the path forward.
              </p>
              <ul className="space-y-2">
                {['Marketing Plans', 'Client Acquisition', 'Pricing Strategy', 'Scaling Roadmap'].map((item, i) => (
                  <li key={i} className="flex items-center gap-2 text-sm text-zinc-600">
                    <CheckCircle className="w-4 h-4 text-green-500" />
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Portfolio Section */}
      <section id="portfolio" className="py-24 md:py-32 px-6 md:px-12 lg:px-24 bg-white">
        <div className="max-w-7xl mx-auto">
          <p className="text-sm uppercase tracking-[0.2em] font-bold text-blue-600 mb-4">Sample Work</p>
          <h2 className="font-heading text-3xl md:text-4xl lg:text-5xl tracking-tight leading-tight font-bold text-zinc-950 mb-6 max-w-2xl">
            See What You'll Get
          </h2>
          <p className="text-lg text-zinc-600 mb-16 max-w-2xl">
            Download real sample documents to see the quality and depth of research that goes into every project.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Sample 1 */}
            <div className="border border-zinc-200 bg-[#FAFAFA] overflow-hidden hover:border-zinc-950 transition-all duration-300">
              <div className="h-64 overflow-hidden">
                <img 
                  src="https://images.unsplash.com/photo-1560066984-138dadb4c035?w=800&q=80" 
                  alt="Beauty aesthetics business" 
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="p-8">
                <span className="text-xs uppercase tracking-widest font-bold text-blue-600">Market Research</span>
                <h3 className="font-heading text-2xl font-bold text-zinc-950 mt-2 mb-3">Beauty Aesthetics Location Analysis</h3>
                <p className="text-zinc-600 mb-6">
                  Comprehensive analysis of the best locations in England for opening a beauty aesthetics clinic. Includes growth data, demographics, and competition analysis.
                </p>
                <button 
                  data-testid="download-sample-pdf-btn"
                  onClick={() => handleDownloadSample('pdf')}
                  className="inline-flex items-center gap-2 bg-zinc-950 text-white px-6 py-3 font-semibold hover:bg-zinc-800 transition-colors rounded-none"
                >
                  <Download className="w-4 h-4" />
                  Download PDF Sample
                </button>
              </div>
            </div>

            {/* Sample 2 */}
            <div className="border border-zinc-200 bg-[#FAFAFA] overflow-hidden hover:border-zinc-950 transition-all duration-300">
              <div className="h-64 overflow-hidden">
                <img 
                  src="https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?w=800&q=80" 
                  alt="Business planning" 
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="p-8">
                <span className="text-xs uppercase tracking-widest font-bold text-blue-600">Business Plan</span>
                <h3 className="font-heading text-2xl font-bold text-zinc-950 mt-2 mb-3">Complete Startup Business Plan</h3>
                <p className="text-zinc-600 mb-6">
                  Full 12-section business plan including startup costs, financial projections, marketing strategy, and step-by-step action plan.
                </p>
                <button 
                  data-testid="download-sample-docx-btn"
                  onClick={() => handleDownloadSample('docx')}
                  className="inline-flex items-center gap-2 bg-zinc-950 text-white px-6 py-3 font-semibold hover:bg-zinc-800 transition-colors rounded-none"
                >
                  <Download className="w-4 h-4" />
                  Download Word Sample
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="py-24 md:py-32 px-6 md:px-12 lg:px-24">
        <div className="max-w-7xl mx-auto">
          <p className="text-sm uppercase tracking-[0.2em] font-bold text-blue-600 mb-4">Investment</p>
          <h2 className="font-heading text-3xl md:text-4xl lg:text-5xl tracking-tight leading-tight font-bold text-zinc-950 mb-16 max-w-2xl">
            Simple, Transparent Pricing
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Starter */}
            <div className="bg-white border border-zinc-200 p-8 hover:border-zinc-950 transition-all duration-300">
              <h3 className="font-heading text-xl font-bold text-zinc-950 mb-2">Starter</h3>
              <p className="text-zinc-600 text-sm mb-6">Perfect for quick insights</p>
              <div className="mb-6">
                <span className="font-heading text-5xl font-black text-zinc-950">£299</span>
              </div>
              <ul className="space-y-3 mb-8">
                {['Market Research Report', 'Location Recommendations', 'Competitor Overview', 'PDF Delivery', '1 Revision'].map((item, i) => (
                  <li key={i} className="flex items-center gap-2 text-sm text-zinc-600">
                    <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
                    {item}
                  </li>
                ))}
              </ul>
              <button 
                data-testid="pricing-starter-btn"
                onClick={() => scrollToSection('contact')}
                className="w-full border-2 border-zinc-950 text-zinc-950 px-6 py-3 font-semibold hover:bg-zinc-950 hover:text-white transition-all rounded-none"
              >
                Get Started
              </button>
            </div>

            {/* Professional */}
            <div className="bg-zinc-950 text-white p-8 relative">
              <div className="absolute top-0 right-0 bg-blue-600 text-white text-xs font-bold px-4 py-1">
                MOST POPULAR
              </div>
              <h3 className="font-heading text-xl font-bold mb-2">Professional</h3>
              <p className="text-zinc-400 text-sm mb-6">Complete business package</p>
              <div className="mb-6">
                <span className="font-heading text-5xl font-black">£549</span>
              </div>
              <ul className="space-y-3 mb-8">
                {['Full Business Plan (Word)', 'Market Research Report', 'Financial Projections', 'Marketing Strategy', '30-min Consultation', '2 Revisions'].map((item, i) => (
                  <li key={i} className="flex items-center gap-2 text-sm text-zinc-300">
                    <CheckCircle className="w-4 h-4 text-green-400 flex-shrink-0" />
                    {item}
                  </li>
                ))}
              </ul>
              <button 
                data-testid="pricing-professional-btn"
                onClick={() => scrollToSection('contact')}
                className="w-full bg-white text-zinc-950 px-6 py-3 font-semibold hover:bg-zinc-100 transition-all rounded-none"
              >
                Get Started
              </button>
            </div>

            {/* Premium */}
            <div className="bg-white border border-zinc-200 p-8 hover:border-zinc-950 transition-all duration-300">
              <h3 className="font-heading text-xl font-bold text-zinc-950 mb-2">Premium</h3>
              <p className="text-zinc-600 text-sm mb-6">Full support & guidance</p>
              <div className="mb-6">
                <span className="font-heading text-5xl font-black text-zinc-950">£899</span>
              </div>
              <ul className="space-y-3 mb-8">
                {['Everything in Professional', 'Custom Financial Model', 'Investor-Ready Format', '2x 30-min Consultations', 'Unlimited Revisions', '30-Day Email Support'].map((item, i) => (
                  <li key={i} className="flex items-center gap-2 text-sm text-zinc-600">
                    <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
                    {item}
                  </li>
                ))}
              </ul>
              <button 
                data-testid="pricing-premium-btn"
                onClick={() => scrollToSection('contact')}
                className="w-full border-2 border-zinc-950 text-zinc-950 px-6 py-3 font-semibold hover:bg-zinc-950 hover:text-white transition-all rounded-none"
              >
                Get Started
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonial */}
      <section className="py-24 md:py-32 px-6 md:px-12 lg:px-24 bg-white">
        <div className="max-w-4xl mx-auto text-center">
          <div className="flex justify-center gap-1 mb-8">
            {[...Array(5)].map((_, i) => (
              <Star key={i} className="w-6 h-6 fill-yellow-400 text-yellow-400" />
            ))}
          </div>
          <blockquote className="font-heading text-2xl md:text-3xl lg:text-4xl tracking-tight font-bold text-zinc-950 mb-8 leading-tight">
            "The business plan was incredibly detailed and professional. It gave me the confidence to finally take the leap and open my own clinic. Worth every penny."
          </blockquote>
          <div className="flex items-center justify-center gap-4">
            <img 
              src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop&crop=face" 
              alt="Sarah Mitchell"
              className="w-14 h-14 rounded-full object-cover"
            />
            <div className="text-left">
              <p className="font-bold text-zinc-950">Sarah Mitchell</p>
              <p className="text-sm text-zinc-600">Aesthetics Clinic Owner, Kent</p>
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-24 md:py-32 px-6 md:px-12 lg:px-24">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center">
            <div>
              <img 
                src="https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=800&q=80" 
                alt="Business consultant" 
                className="w-full h-[500px] object-cover"
              />
            </div>
            <div>
              <p className="text-sm uppercase tracking-[0.2em] font-bold text-blue-600 mb-4">About</p>
              <h2 className="font-heading text-3xl md:text-4xl lg:text-5xl tracking-tight leading-tight font-bold text-zinc-950 mb-6">
                Helping Small Businesses Succeed
              </h2>
              <p className="text-lg text-zinc-600 mb-6 leading-relaxed">
                I'm Nicholas Robinson, and I help entrepreneurs and small business owners turn their ideas into thriving businesses. I provide the insights and planning documents you need to start strong and scale fast.
              </p>
              <p className="text-lg text-zinc-600 mb-8 leading-relaxed">
                Every business plan I create is tailored to your specific situation - your industry, your location, your budget. No generic templates, just actionable strategies based on real data and market research.
              </p>
              <div className="grid grid-cols-3 gap-6">
                <div>
                  <p className="font-heading text-4xl font-black text-zinc-950">150+</p>
                  <p className="text-sm text-zinc-600">Plans Created</p>
                </div>
                <div>
                  <p className="font-heading text-4xl font-black text-zinc-950">50+</p>
                  <p className="text-sm text-zinc-600">Industries</p>
                </div>
                <div>
                  <p className="font-heading text-4xl font-black text-zinc-950">98%</p>
                  <p className="text-sm text-zinc-600">Satisfaction</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-24 md:py-32 px-6 md:px-12 lg:px-24 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16">
            <div>
              <p className="text-sm uppercase tracking-[0.2em] font-bold text-blue-600 mb-4">Get In Touch</p>
              <h2 className="font-heading text-3xl md:text-4xl lg:text-5xl tracking-tight leading-tight font-bold text-zinc-950 mb-6">
                Ready to Get Started?
              </h2>
              <p className="text-lg text-zinc-600 mb-8 leading-relaxed">
                Book a free 15-minute consultation to discuss your business idea. No obligation, just honest advice on whether I can help.
              </p>
              
              <div className="space-y-6">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-blue-50 flex items-center justify-center">
                    <Mail className="w-5 h-5 text-blue-600" />
                  </div>
                  <div>
                    <p className="text-sm text-zinc-500">Email</p>
                    <p className="font-semibold text-zinc-950">nicholasrobinson@launchpad-consulting.co.uk</p>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-blue-50 flex items-center justify-center">
                    <MapPin className="w-5 h-5 text-blue-600" />
                  </div>
                  <div>
                    <p className="text-sm text-zinc-500">Location</p>
                    <p className="font-semibold text-zinc-950">United Kingdom</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-[#FAFAFA] border border-zinc-200 p-8">
              {formSubmitted ? (
                <div className="text-center py-12">
                  <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
                  <h3 className="font-heading text-2xl font-bold text-zinc-950 mb-2">Message Sent!</h3>
                  <p className="text-zinc-600">I'll get back to you within 24 hours.</p>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div>
                    <label className="block text-sm font-semibold text-zinc-950 mb-2">Your Name</label>
                    <input 
                      type="text" 
                      data-testid="contact-name-input"
                      required
                      value={formData.name}
                      onChange={(e) => setFormData({...formData, name: e.target.value})}
                      className="w-full px-4 py-3 bg-white border border-zinc-200 focus:border-zinc-950 focus:ring-2 focus:ring-zinc-950 outline-none transition-all rounded-none"
                      placeholder="John Smith"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-zinc-950 mb-2">Email Address</label>
                    <input 
                      type="email" 
                      data-testid="contact-email-input"
                      required
                      value={formData.email}
                      onChange={(e) => setFormData({...formData, email: e.target.value})}
                      className="w-full px-4 py-3 bg-white border border-zinc-200 focus:border-zinc-950 focus:ring-2 focus:ring-zinc-950 outline-none transition-all rounded-none"
                      placeholder="john@example.com"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-zinc-950 mb-2">Business Type</label>
                    <input 
                      type="text" 
                      data-testid="contact-business-input"
                      value={formData.business}
                      onChange={(e) => setFormData({...formData, business: e.target.value})}
                      className="w-full px-4 py-3 bg-white border border-zinc-200 focus:border-zinc-950 focus:ring-2 focus:ring-zinc-950 outline-none transition-all rounded-none"
                      placeholder="e.g., Beauty Salon, Café, Online Store"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-zinc-950 mb-2">Tell Me About Your Project</label>
                    <textarea 
                      data-testid="contact-message-input"
                      required
                      rows={4}
                      value={formData.message}
                      onChange={(e) => setFormData({...formData, message: e.target.value})}
                      className="w-full px-4 py-3 bg-white border border-zinc-200 focus:border-zinc-950 focus:ring-2 focus:ring-zinc-950 outline-none transition-all rounded-none resize-none"
                      placeholder="What do you need help with?"
                    />
                  </div>
                  <button 
                    type="submit"
                    data-testid="contact-submit-btn"
                    className="w-full bg-zinc-950 text-white px-8 py-4 font-semibold hover:bg-zinc-800 transition-all rounded-none inline-flex items-center justify-center gap-2"
                  >
                    Send Message
                    <ChevronRight className="w-5 h-5" />
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-zinc-950 text-white py-24 md:py-32 px-6 md:px-12 lg:px-24">
        <div className="max-w-7xl mx-auto">
          <h2 className="font-heading text-[12vw] md:text-[10vw] lg:text-[8vw] font-black tracking-tighter leading-none mb-16 text-zinc-100">
            Ready to<br />Scale?
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 pt-12 border-t border-zinc-800">
            <div>
              <p className="font-heading font-black text-xl mb-4">LAUNCHPAD</p>
              <p className="text-zinc-500 text-sm">Business consulting for ambitious entrepreneurs.</p>
            </div>
            <div>
              <p className="font-bold text-sm uppercase tracking-wider mb-4 text-zinc-400">Services</p>
              <ul className="space-y-2 text-zinc-500">
                <li><a href="#services" className="hover:text-white transition-colors">Business Plans</a></li>
                <li><a href="#services" className="hover:text-white transition-colors">Market Research</a></li>
                <li><a href="#services" className="hover:text-white transition-colors">Growth Strategy</a></li>
              </ul>
            </div>
            <div>
              <p className="font-bold text-sm uppercase tracking-wider mb-4 text-zinc-400">Company</p>
              <ul className="space-y-2 text-zinc-500">
                <li><a href="#about" className="hover:text-white transition-colors">About</a></li>
                <li><a href="#portfolio" className="hover:text-white transition-colors">Portfolio</a></li>
                <li><a href="#pricing" className="hover:text-white transition-colors">Pricing</a></li>
              </ul>
            </div>
            <div>
              <p className="font-bold text-sm uppercase tracking-wider mb-4 text-zinc-400">Contact</p>
              <ul className="space-y-2 text-zinc-500">
                <li>nicholasrobinson@launchpad-consulting.co.uk</li>
                <li>United Kingdom</li>
              </ul>
            </div>
          </div>
          <div className="mt-16 pt-8 border-t border-zinc-800 text-center text-zinc-600 text-sm">
            © 2025 Launchpad Consulting. All rights reserved.
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;
